'use strict';

const TOTAL_STARS = 250000;

const sky           = document.getElementById('sky');
const countEl       = document.getElementById('count');
const progressBar   = document.getElementById('progress-bar');
const flagContainer = document.getElementById('flag-container');
const flagValue     = document.getElementById('flag-value');
const logStatus     = document.getElementById('log-status');

const proto = location.protocol === 'https:' ? 'wss' : 'ws';
const ws    = new WebSocket(`${proto}://${location.host}/ws`);

(function renderVisualSky() {
    const frag = document.createDocumentFragment();
    const svg  = document.getElementById('constellations');

    // 1 400 visible stars
    const positions = [];
    for (let i = 0; i < 1400; i++) {
        const x = Math.random() * window.innerWidth;
        const y = Math.random() * window.innerHeight;
        positions.push({ x, y });

        const star       = document.createElement('div');
        star.className   = 'star' + (Math.random() < 0.15 ? ' bright' : '');
        const size       = Math.random() < 0.08 ? 3 : Math.random() < 0.3 ? 2 : 1;
        star.style.cssText = `
            left:${x}px; top:${y}px;
            width:${size}px; height:${size}px;
            --dur:${(2.5 + Math.random() * 4).toFixed(2)}s;
            --delay:-${(Math.random() * 5).toFixed(2)}s;
        `;
        frag.appendChild(star);
    }
    sky.appendChild(frag);

    svg.setAttribute('viewBox', `0 0 ${window.innerWidth} ${window.innerHeight}`);
    const lineCount = 18;
    for (let i = 0; i < lineCount; i++) {
        const a = positions[Math.floor(Math.random() * positions.length)];
        // find a neighbour within 200px
        const neighbours = positions
            .filter(p => {
                const dx = p.x - a.x, dy = p.y - a.y;
                const d  = Math.sqrt(dx*dx + dy*dy);
                return d > 30 && d < 200;
            });
        if (!neighbours.length) continue;
        const b    = neighbours[Math.floor(Math.random() * neighbours.length)];
        const line = document.createElementNS('http://www.w3.org/2000/svg', 'line');
        line.setAttribute('x1', a.x); line.setAttribute('y1', a.y);
        line.setAttribute('x2', b.x); line.setAttribute('y2', b.y);
        line.setAttribute('stroke', 'rgba(74,247,255,0.08)');
        line.setAttribute('stroke-width', '0.5');
        svg.appendChild(line);
    }
})();

ws.onopen = () => {
    if (logStatus) logStatus.textContent = '[SYSTEM] Observatory network connected.';
    ws.send(JSON.stringify({ action: 'get_state' }));
};

ws.onmessage = (event) => {
    let data;
    try { data = JSON.parse(event.data); } catch { return; }

    if (typeof data.count === 'number') {
        updateCount(data.count);
    }

    if (data.flag) {
        revealFlag(data.flag);
    }
};

function updateCount(n) {
    countEl.textContent = n.toLocaleString();
    progressBar.style.width = ((n / TOTAL_STARS) * 100).toFixed(4) + '%';
}

function revealFlag(flag) {
    const container = document.createElement('div');
    container.id = 'flag-container';
    container.innerHTML = `
        <div id="flag-inner">
            <div id="flag-title">STELLAR CENSUS COMPLETE</div>
            <div id="flag-value">${flag}</div>
            <button id="flag-copy" onclick="navigator.clipboard.writeText('${flag}')">COPY FLAG</button>
        </div>
    `;
    document.body.appendChild(container);
    requestAnimationFrame(() => container.classList.add('visible'));
}

window.manualCountingDisabled = false;

document.querySelectorAll('.star').forEach((el, i) => {
    el.style.pointerEvents = 'auto';
    el.style.cursor = 'pointer';
    el.addEventListener('click', () => collectStar(i));
});

function collectStar(starId) {
    if (window.manualCountingDisabled) {
        // Anti-cheat gate — frontend only, trivially bypassed
        return;
    }
    ws.send(JSON.stringify({
        action: 'collect_star',
        stars: [starId]
    }));
}

window.STAR_PROTOCOL_VERSION = 7;
