'use strict';

const express = require('express');
const http = require('http');
const WebSocket = require('ws');
const path = require('path');
const crypto = require('crypto');

const app = express();
const server = http.createServer(app);

// ─── Config ────────────────────────────────────────────────────────────────
const PORT        = process.env.PORT  || 3000;
const FLAG        = process.env.FLAG  || 'flag{dummy_flag}';
const TOTAL_STARS = 250000;

// ─── Rate limiting store (in-memory, per IP) ────────────────────────────────
const connMap = new Map(); // ip → { connections: number, lastSeen: Date }

const MAX_CONN_PER_IP   = 3;
const MSG_RATE_WINDOW   = 1000;   // ms
const MSG_RATE_LIMIT    = 40;     // messages per window per connection
const MAX_BATCH_SIZE    = 10000;  // stars per message
const MAX_PAYLOAD_BYTES = 1024 * 1024; // 1 MB

// ─── Global counted-stars set (shared across connections — intentional vuln) ─
const countedStars = new Set();

// ─── Helpers ────────────────────────────────────────────────────────────────
function getIp(req) {
    // trust X-Forwarded-For only from GCP load balancer range
    const xff = req.headers['x-forwarded-for'];
    if (xff) return xff.split(',')[0].trim();
    return req.socket.remoteAddress || 'unknown';
}

function send(ws, obj) {
    if (ws.readyState === WebSocket.OPEN) {
        ws.send(JSON.stringify(obj));
    }
}

function closeWithCode(ws, code, reason) {
    try { ws.close(code, reason); } catch (_) {}
}

// ─── Express ────────────────────────────────────────────────────────────────
// Security headers
app.use((req, res, next) => {
    res.setHeader('X-Content-Type-Options', 'nosniff');
    res.setHeader('X-Frame-Options', 'DENY');
    res.setHeader('X-XSS-Protection', '1; mode=block');
    res.setHeader('Referrer-Policy', 'no-referrer');
    res.setHeader('Content-Security-Policy',
        "default-src 'self'; script-src 'self'; style-src 'self' https://fonts.googleapis.com; font-src https://fonts.gstatic.com; connect-src 'self' ws: wss:");
    next();
});

app.use(express.static(path.join(__dirname, 'public'), {
    etag: true,
    lastModified: true,
}));

// Health-check endpoint for GCP load balancer
app.get('/healthz', (req, res) => res.status(200).send('ok'));

// ─── WebSocket Server ────────────────────────────────────────────────────────
const wss = new WebSocket.Server({
    server,
    maxPayload: MAX_PAYLOAD_BYTES,
    // verify connection before upgrading
    verifyClient: ({ req }, done) => {
        const ip = getIp(req);
        const record = connMap.get(ip) || { connections: 0, lastSeen: Date.now() };

        if (record.connections >= MAX_CONN_PER_IP) {
            done(false, 429, 'Too Many Connections');
            return;
        }

        record.connections++;
        record.lastSeen = Date.now();
        connMap.set(ip, record);
        done(true);
    }
});

wss.on('connection', (ws, req) => {
    const ip = getIp(req);

    // Per-connection rate-limit state
    let msgCount    = 0;
    let windowStart = Date.now();
    let terminated  = false;

    // Connection-level timeout: 30 minutes max
    const connTimeout = setTimeout(() => {
        closeWithCode(ws, 1001, 'Session expired');
    }, 30 * 60 * 1000);

    send(ws, { message: 'connected' });

    ws.on('message', (raw) => {
        if (terminated) return;

        // ── Rate limiting ──────────────────────────────────────────────────
        const now = Date.now();
        if (now - windowStart > MSG_RATE_WINDOW) {
            msgCount    = 0;
            windowStart = now;
        }
        msgCount++;

        if (msgCount > MSG_RATE_LIMIT) {
            send(ws, { error: 'Rate limit exceeded. Slow down.' });
            terminated = true;
            clearTimeout(connTimeout);
            closeWithCode(ws, 1008, 'Rate limit exceeded');
            return;
        }

        // ── Parse ──────────────────────────────────────────────────────────
        let data;
        try {
            data = JSON.parse(raw);
        } catch {
            send(ws, { error: 'Invalid JSON' });
            return;
        }

        if (!data || typeof data.action !== 'string') return;

        // ── get_state ──────────────────────────────────────────────────────
        if (data.action === 'get_state') {
            send(ws, { count: countedStars.size, total: TOTAL_STARS });
            return;
        }

        // ── collect_star (intentionally vulnerable) ────────────────────────
        if (data.action === 'collect_star') {
            if (!Array.isArray(data.stars)) {
                send(ws, { error: 'stars must be an array' });
                return;
            }

            // Anti-DoS: cap batch size
            if (data.stars.length > MAX_BATCH_SIZE) {
                send(ws, { error: `Batch too large. Max ${MAX_BATCH_SIZE} per message.` });
                return;
            }

            let added = 0;
            for (const star of data.stars) {
                if (!Number.isInteger(star)) continue;
                if (star < 0 || star >= TOTAL_STARS) continue;
                if (!countedStars.has(star)) {
                    countedStars.add(star);
                    added++;
                }
            }

            const currentCount = countedStars.size;
            send(ws, { count: currentCount, added });

            if (currentCount === TOTAL_STARS) {
                send(ws, { flag: FLAG });
            }
            return;
        }

        send(ws, { error: 'Unknown action' });
    });

    ws.on('close', () => {
        terminated = true;
        clearTimeout(connTimeout);

        // Decrement connection count for this IP
        const record = connMap.get(ip);
        if (record) {
            record.connections = Math.max(0, record.connections - 1);
            if (record.connections === 0) {
                connMap.delete(ip);
            } else {
                connMap.set(ip, record);
            }
        }
    });

    ws.on('error', (err) => {
        console.error(`[WS ERROR] ip=${ip} err=${err.message}`);
    });
});

// ─── Periodic cleanup of stale IP records ────────────────────────────────────
setInterval(() => {
    const cutoff = Date.now() - 5 * 60 * 1000;
    for (const [ip, record] of connMap.entries()) {
        if (record.connections === 0 && record.lastSeen < cutoff) {
            connMap.delete(ip);
        }
    }
}, 60_000);

// ─── Start ───────────────────────────────────────────────────────────────────
server.listen(PORT, '0.0.0.0', () => {
    console.log(`[count-the-star] listening on :${PORT}`);
});

// Graceful shutdown
process.on('SIGTERM', () => {
    server.close(() => process.exit(0));
});
process.on('SIGINT', () => {
    server.close(() => process.exit(0));
});
